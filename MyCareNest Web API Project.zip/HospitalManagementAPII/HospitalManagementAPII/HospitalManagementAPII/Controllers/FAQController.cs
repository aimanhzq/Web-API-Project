﻿using Microsoft.AspNetCore.Mvc;

namespace HospitalManagementAPII.Controllers
{
    public class FAQController : Controller
    {
        // GET: /FAQ
        public IActionResult Index()
        {
            // Render the FAQ view
            return View();
        }
    }
}

