﻿using Microsoft.AspNetCore.Mvc;

namespace HospitalManagementAPII.Controllers
{
    public class AboutUsController : Controller
    {
        // GET: /AboutUs
        public IActionResult Index()
        {
            // Render the About Us view
            return View();
        }
    }
}

